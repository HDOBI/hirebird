import React from "react";
import SelectPackage from "./SelectPackage";
import data from "@/app/utility/subscribe.json";

function Subscribe() {
  const { plans } = data;

  return (
    <div className="flex flex-col p-10 items-center justify-center max-w-[440px] shadow-priceBox  mx-auto text-center pb-20 mt-72 px-3 md:px-0 rounded-[20px]">
      <h5 className="text-forestGreen font-medium text-[20px]">overview</h5>
      <p>Confirm your cosemose plan</p>
      <div className="mt-6 w-full">
        <SelectPackage
          packageName={plans.yearly.packageName}
          price={plans.yearly.price}
        />
      </div>
      <div className="mt-6 w-full">
        <SelectPackage
          packageName={plans.monthly.packageName}
          price={plans.monthly.price}
        />
      </div>
      <div className="flex flex-col gap-2.5">
        {plans.monthly.billDatils.map((item, id) => (
          <div className="flex items-center justify-between">
            <div>
              <span>{item.heading}</span>
            </div>
            <div>
              <span>{item.value}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Subscribe;
